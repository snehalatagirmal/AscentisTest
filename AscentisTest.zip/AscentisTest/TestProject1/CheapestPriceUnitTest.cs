using AscentisProgram;
using NUnit.Framework;

namespace TestProject1
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void TestMethod1()
        {
            int n = 4, src = 0, dst = 3, k = 1;
            CheapestPrice p = new CheapestPrice();
            int[][] flights = new int[][]{
            new int[] { 0,1,100 },
            new int[] { 1,2,100 },
            new int[] { 2,0,100 },
            new int[] { 1,3,600 },
            new int[] { 2,3,200 }
             };
            int x = p.FindCheapestPrice(n, flights,
            src, dst, k);
            Assert.AreEqual(700, x);
            Assert.NotNull(x);
            Assert.Pass();
        }

        [Test]
        public void TestMethod2()
        {
            int n = 3, src = 0, dst = 2, k = 1;
            CheapestPrice p = new CheapestPrice();
            int[][] flights = new int[][]{
            new int[] { 0,1,100 },
            new int[] { 1,2,100 },
            new int[] { 0,2,500 }
             };
            int x = p.FindCheapestPrice(n, flights,
            src, dst, k);
            Assert.AreEqual(200, x);
            Assert.NotNull(x);
            Assert.Pass();
        }

        [Test]
        public void TestMethod3()
        {
            int n = 3, src = 0, dst = 2, k = 0;
            CheapestPrice p = new CheapestPrice();
            int[][] flights = new int[][]{
            new int[] { 0,1,100 },
            new int[] { 1,2,100 },
            new int[] { 0,2,500 }
             };
            int x = p.FindCheapestPrice(n, flights,
            src, dst, k);
            Assert.AreEqual(500, x);
            Assert.NotNull(x);
            Assert.Pass();
        }

        [Test]
        public void TestMethod4()
        {
            int n = 5, src = 0, dst = 4, k = 2;
            CheapestPrice p = new CheapestPrice();
            int[][] flights = new int[][]{
            new int[] { 0,1,100 },
            new int[] { 1,2,100 },
            new int[] { 3,4,200 },
            new int[] { 0,2,500 },
            new int[] { 2,4,100 },
            new int[] { 1,3,600 },
            new int[] { 2,3,200 }
             };
            int x = p.FindCheapestPrice(n, flights,
            src, dst, k);
            Assert.AreEqual(300, x);
            Assert.NotNull(x);
            Assert.Pass();
        }


        [Test]
        public void TestMethod5()
        {
            int n = 5, src = 0, dst = 4, k = 2;
            CheapestPrice p = new CheapestPrice();
            int[][] flights = new int[][]{
            new int[] { 0,1,100 },
            new int[] { 1,2,100 },
            new int[] { 3,4,200 },
            new int[] { 0,2,500 },
            new int[] { 1,3,600 },
            new int[] { 2,3,200 }
             };
            int x = p.FindCheapestPrice(n, flights,
            src, dst, k);
            Assert.AreEqual(-1, x);
            Assert.NotNull(x);
            Assert.Pass();
        }


        [Test]
        public void TestMethod6()
        {
            int n = 5, src = 0, dst = 4, k = -1;
            CheapestPrice p = new CheapestPrice();
            int[][] flights = new int[][]{
            new int[] { 0,1,100 },
            new int[] { 1,2,100 },
            new int[] { 3,4,200 },
            new int[] { 0,2,500 },
            new int[] { 2,4,100 },
            new int[] { 1,3,600 },
            new int[] { 2,3,200 }
             };
            int x = p.FindCheapestPrice(n, flights,
            src, dst, k);
            Assert.AreEqual(-1, x);
            Assert.NotNull(x);
            Assert.Pass();
        }

        [Test]
        public void TestMethod7()
        {
            int n = 5, src = 0, dst = 4, k = 2;
            CheapestPrice p = new CheapestPrice();
            int[][] flights = new int[][]{
            new int[] { 0,1,100 },
            new int[] { 1,2,100 },
            new int[] { 3,4,200 },
            new int[] { 0,2,500 },
            new int[] { 4,2,100 },
            new int[] { 1,3,600 },
            new int[] { 4,3,200 }
             };
            int x = p.FindCheapestPrice(n, flights,
            src, dst, k);
            Assert.AreEqual(-1, x);
            Assert.NotNull(x);
            Assert.Pass();
        }

        [Test]
        public void TestMethod8()
        {
            int n = 3, src = 0, dst = 3, k = 1;
            CheapestPrice p = new CheapestPrice();
            int[][] flights = new int[][]{
            new int[] { 0,1,200 },
            new int[] { 0,2,100 },
            new int[] { 1,2,100 },
            new int[] { 3,2,500 }
             };
            int x = p.FindCheapestPrice(n, flights,
            src, dst, k);
            Assert.AreEqual(-1, x);
            Assert.NotNull(x);
            Assert.Pass();
        }

        [Test]
        public void TestMethod9()
        {
            int n = 4, src = 0, dst = 3, k = 1;
            CheapestPrice p = new CheapestPrice();
            int[][] flights = new int[][]{
            new int[] { 0,1,200 },
            new int[] { 0,2,100 },
            new int[] { 1,2,100 },
            new int[] { 2,3,500 }
             };
            int x = p.FindCheapestPrice(n, flights,
            src, dst, k);
            Assert.AreEqual(600, x);
            Assert.NotNull(x);
            Assert.Pass();
        }

    }
}