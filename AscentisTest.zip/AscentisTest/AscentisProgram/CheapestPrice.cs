﻿using System;
using System.Linq;

namespace AscentisProgram
{
   public class CheapestPrice
    {
        public int FindCheapestPrice(int n, int[][] flights, int src, int dst, int k)
        {
            int price = -1;
            if (k == 0)
            {
                for (int i = 0; i < flights.Length; i++)
                {
                    for (int j = 0; j < flights[i].Length; j++)
                    {

                        if (flights[i][0] == src && flights[i][1] == dst)
                        {
                            price = (flights[i][2]);
                        }
                    }
                }
               
            }
            else if (k == 1)
            {
                int chepatestPrice = 0; int nextpoint = 0;
                Array.Sort(flights, (x, y) => x[2].CompareTo(y[2]));

                for (int i = 0; i < flights.Length; i++)
                {
                    if (flights[i][0] == src && nextpoint == 0)
                    {
                        nextpoint = flights[i][1];
                        chepatestPrice = flights[i][2];
                    }
                    if (flights[i][0] == nextpoint && flights[i][1] == dst)
                    {
                        price = chepatestPrice + flights[i][2];                        
                        break;
                    }
                }
                return price;
            }
            else if (k > 1)
            {               
                price = Cheapeprice(src, dst, flights, 0, 0, k,price);
                return price;
            }
            else
                return price;
            return price;
        }

        static int Cheapeprice(int nextpoint, int dst, int[][] flights, int cheapestPrice, int round, int k, int price)
        {           
            Array.Sort(flights, (x, y) => x[2].CompareTo(y[2]));
            for (int i = 0; i < flights.Length; i++)
            {
                if (flights[i][0] == nextpoint && nextpoint < dst && round < k)
                {
                    nextpoint = flights[i][1];
                    cheapestPrice = cheapestPrice + flights[i][2];                    
                    flights = flights.Where((arr, p) => p != i)
                         .Select(arr => arr.ToArray())
                         .ToArray();
                    break;
                }
                if (flights[i][0] == nextpoint && flights[i][1] == dst)
                {
                    nextpoint = flights[i][1];
                    price = cheapestPrice + flights[i][2];
                    flights = flights.Where((arr, p) => p != i)
                         .Select(arr => arr.ToArray())
                         .ToArray();
                    break;
                }
            }

            round = round + 1;
            if (nextpoint < dst && round <= k)
            {
                return Cheapeprice(nextpoint, dst, flights, cheapestPrice, round, k, price);                              
            }
            else
            {
                return price;               
            }

        }

        static void Main(string[] args)
        {
            CheapestPrice p = new CheapestPrice();
            int[][] myarra = new int[][]{
            new int[] { 0,1,100 },
            new int[] { 1,2,100 },
            new int[] { 3,4,200 },
            new int[] { 0, 2, 500 },
            new int[] { 2,4,100 },
            new int[] { 1, 3, 600 },
            new int[] { 2, 3, 200 }
             };
            Console.WriteLine(p.FindCheapestPrice(5, myarra,
            0, 4, 2));
            Console.ReadLine();
        }
    }
}
